# -*- coding: utf-8 -*-
"""
Created on Wed Aug 30 18:26:38 2023

@author: panti
"""

#8.5 iteration
import pandas as pd

file = 'merged_data.csv'
merged_data = pd.read_csv(file)
merged_data["Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized"].describe()

import numpy as np

death_share_median = merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].median()

death_share_q1 = merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].quantile(0.25)

death_share_q3 = merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].quantile(0.75)

def death_share_class(death_share):
    if death_share <= death_share_q1:
        return 'low-risk from unsafe water'
    elif death_share_q1 < death_share <= death_share_q3:
        return 'medium-risk from unsafe water'
    else:
        return 'high-risk from unsafe water'
    
merged_data['death_share_risk'] = merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].map(death_share_class)

merged_data.to_csv('merged_data_iteration.csv', index=False)

print(merged_data['death_share_risk'].value_counts())
'''
medium-risk from unsafe water    539
low-risk from unsafe water       270
high-risk from unsafe water      270
'''
from sklearn.utils import resample

merged_data_high = merged_data[merged_data['death_share_risk'] == 'medium-risk from unsafe water']
merged_data_low = merged_data[merged_data['death_share_risk'] == 'high-risk from unsafe water']
merged_data_low_boost_high = resample(merged_data_low,replace=True, n_samples=len(merged_data_high))
merged_data_low = merged_data[merged_data['death_share_risk'] == 'low-risk from unsafe water']
merged_data_low_boost_low = resample(merged_data_low,replace=True, n_samples=len(merged_data_high))
merged_data_boost = pd.concat([merged_data_high, merged_data_low_boost_high, merged_data_low_boost_low])

print(merged_data_boost['death_share_risk'].value_counts())
'''
print(merged_data_boost['death_share_risk'].value_counts())
medium-risk from unsafe water    539
high-risk from unsafe water      539
low-risk from unsafe water       539
'''
merged_data_boost.to_csv('merged_data_boost_iteration.csv', index=False)


death_share_risk_map = {'high-risk from unsafe water': 2, 'medium-risk from unsafe water': 1, 'low-risk from unsafe water': 0}
merged_data_boost['death_share_risk'] = merged_data_boost['death_share_risk'].map(death_share_risk_map)

income_class_map = {'Low Income': 1, 'Middle Income': 2, 'High Income': 3}
merged_data_boost["income_class"] = merged_data_boost["income_class"].map(income_class_map)


Y = merged_data_boost['death_share_risk']
X = merged_data_boost.drop(['Entity', 'Code', 'Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized', 'death_share_risk'], axis = 1)
from sklearn.model_selection import train_test_split
X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size = 0.3,  random_state=40)

#random forest
from sklearn.ensemble import RandomForestClassifier
c2 = RandomForestClassifier(n_estimators=300, random_state=40)
c2.fit(X_train, Y_train)

import matplotlib.pyplot as plt
import numpy as np
importances = c2.feature_importances_
features = X.columns
for i in range(15):
    print(features[i], "" , importances[i])
    
indices = np.argsort(importances) 
'''
plt.figure(figsize=(10,12))
plt.title('Feature Importances')
plt.barh(range(len(indices)), importances[indices], align='center')
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.xlabel('Relative Importance')
plt.show()
'''
import shap
explainer = shap.TreeExplainer(c2)
shap_values = explainer.shap_values(X_test)

shap.summary_plot(shap_values, X_test)
"""
shap.dependence_plot("country_physicians_proportion", shap_values[1], X_test)
shap.dependence_plot("wat_sm", shap_values[1], X_test)
shap.dependence_plot("san_od", shap_values[1], X_test)
shap.dependence_plot("wat_sur", shap_values[1], X_test)
shap.dependence_plot("wat_bas_minus_sm", shap_values[1], X_test)
shap.dependence_plot("death_share_diarrheal_disease",shap_values[1], X_test)
shap.dependence_plot("GDP per capita, PPP (constant 2017 international $)", shap_values[1], X_test)
shap.dependence_plot("wat_lim", shap_values[1], X_test)
shap.dependence_plot("wat_imp", shap_values[1], X_test)
shap.dependence_plot("wat_imp_without_share",shap_values[1], X_test)
shap.dependence_plot("income_class", shap_values[1], X_test)
shap.dependence_plot("Population (historical estimates)", shap_values[1], X_test)
shap.dependence_plot("Domestic general government health expenditure (% of GDP)", shap_values[1], X_test)
shap.dependence_plot("wat_unimp", shap_values[1], X_test)
"""
c2.score(X_test, Y_test)
c2.score(X_train, Y_train)


