# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 19:13:57 2023

@author: panti
"""

#data preparation
import pandas as pd

file = 'access-drinking-water-stacked.csv'
access_drinking = pd.read_csv(file)
#file2 = 'death-rates-unsafe-water.csv'
#death_rates_unsafe_water = pd.read_csv(file2)
file3 = 'share-deaths-unsafe-water.csv'
death_share_unsafe_water = pd.read_csv(file3)
file4 =  'deaths-from-diarrheal-diseases-who.csv'
death_from_diarrheal_disease = pd.read_csv(file4)
file5 = 'historical-gov-spending-gdp.csv'
gov_spending = pd.read_csv(file5)
file6 = 'improved-water-sources-vs-gdp-per-capita.csv'
improved_water_sources_vs_gdp = pd.read_csv(file6)
file7 = 'number-without-improved-water.csv'
number_without_improved_water = pd.read_csv(file7)
file8 = 'number-without-safe-drinking-water.csv'
number_without_safe_drinking_water = pd.read_csv(file8)
file9= 'people-practicing-open-defecation-of-population.csv'
open_defecation = pd.read_csv(file9)
file10 = 'physicians-per-1000-people.csv'
physicians_number = pd.read_csv(file10)
file11 = 'public-healthcare-spending-share-gdp.csv'
healthcare_spending = pd.read_csv(file11)
#file12 = 'public-health-expenditure-share-GDP-OWID.csv'
#health_expenditure_share_GDP = pd.read_csv(file12)
#file13 = 'healthcare-expenditure-vs-gdp.csv'
#healthcare_expenditure_vs_GDP = pd.read_csv(file13)
file14 = 'water-bodies-good-water-quality.csv'
water_bodies_quality = pd.read_csv(file14)

merged_data = pd.merge(death_share_unsafe_water, access_drinking, on=['Entity', 'Year', 'Code'], how='inner')
merged_data = pd.merge(merged_data, death_from_diarrheal_disease, on=['Entity', 'Year','Code'], how='inner')
merged_data = pd.merge(merged_data, improved_water_sources_vs_gdp, on=['Entity', 'Year','Code'], how='inner')
merged_data = pd.merge(merged_data, number_without_improved_water, on=['Entity', 'Year','Code'], how='inner')
merged_data = pd.merge(merged_data, open_defecation, on=['Entity', 'Year','Code'], how='inner')
merged_data = pd.merge(merged_data, healthcare_spending, on=['Entity', 'Year','Code'], how='inner')

merged_data = pd.merge(merged_data, number_without_safe_drinking_water, on=['Entity', 'Year','Code'], how='left')
merged_data = pd.merge(merged_data, physicians_number, on=['Entity', 'Year','Code'], how='left')



#merged_data = pd.merge(merged_data, health_expenditure_share_GDP, on=['Entity', 'Year','Code'], how='inner')
merged_data = pd.merge(merged_data, water_bodies_quality, on=['Entity', 'Year','Code'], how='left')
#merged_data = pd.merge(merged_data, health_facilities_medicines, on=['Entity', 'Year','Code'], how='inner')
merged_data.to_csv('merged_data.csv', index=False)

#data cleaning
merged_data.isnull().mean()
#delete continent column
merged_data = merged_data.drop(columns=['Continent'])
merged_data = merged_data.drop(columns=['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'])
merged_data = merged_data.drop(columns=['6.3.2 - Proportion of river water bodies with good ambient water quality (%) - EN_H2O_RVAMBQ'])
merged_data = merged_data.drop(columns=['6.3.2 - Proportion of groundwater bodies with good ambient water quality (%) - EN_H2O_GRAMBQ'])
merged_data = merged_data.drop(columns=['6.3.2 - Proportion of open water bodies with good ambient water quality (%) - EN_H2O_OPAMBQ'])
#delete wat_sm row
merged_data = merged_data.dropna(subset=['wat_sm', 'wat_bas_minus_sm'], how='all')
merged_data.isnull().mean()
#impute wat_sur
wat_sur_mean = merged_data.groupby('Entity')['wat_sur'].transform('mean')
merged_data['wat_sur'].fillna(wat_sur_mean, inplace=True)
merged_data.isnull().mean()
##impute physician
physician_mean = merged_data.groupby('Entity')['Physicians (per 1,000 people)'].transform('mean')
merged_data['Physicians (per 1,000 people)'].fillna(physician_mean, inplace=True)
merged_data.isnull().mean()
#impute GDP
GDP_per_capita_mean = merged_data.groupby('Entity')['GDP per capita, PPP (constant 2017 international $)'].transform('mean')
merged_data['GDP per capita, PPP (constant 2017 international $)'].fillna(GDP_per_capita_mean, inplace=True)
merged_data.isnull().mean()



'''
water_bodies_2017 = merged_data[merged_data['Year'] == 2017].set_index('Entity')['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'].to_dict()
merged_data['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'] = merged_data.groupby('Entity')['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'].fillna(merged_data['Entity'].map(water_bodies_2017))

water_bodies_2020 = merged_data[merged_data['Year'] == 2020].set_index('Entity')['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'].to_dict()
merged_data['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'] = merged_data.groupby('Entity')['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ'].fillna(merged_data['Entity'].map(water_bodies_2020))
'''







merged_data.to_csv('merged_data.csv', index=False)







#scatter plot to check outliers and extremes
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index, merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized']) 
plt.title('Scatter Plot for death') 
plt.xlabel('Index')
plt.ylabel('death share ')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index, merged_data['wat_sm']) 
plt.title('Scatter Plot for wat_sm') 
plt.xlabel('Index')
plt.ylabel('percentage ')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_bas_minus_sm']) 
plt.title('Scatter Plot for wat_bas_minus_sm') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()
outliers = merged_data[merged_data['wat_bas_minus_sm'] > 68]
print(outliers)

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_unimp']) 
plt.title('Scatter Plot for wat_unimp') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_sur']) 
plt.title('Scatter Plot for wat_sur') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges']) 
plt.title('Scatter Plot for death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges') 
plt.xlabel('Index')
plt.ylabel('count')  
plt.show()
rows_to_drop = merged_data[merged_data['Entity'] == 'World'].index
merged_data = merged_data.drop(rows_to_drop)

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_imp']) 
plt.title('wat_imp') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['GDP per capita, PPP (constant 2017 international $)']) 
plt.title('GDP per capita, PPP (constant 2017 international $)') 
plt.xlabel('Index')
plt.ylabel('value')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['Population (historical estimates)']) 
plt.title('Population (historical estimates)') 
plt.xlabel('Index')
plt.ylabel('value')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_imp_number_without']) 
plt.title('wat_imp_number_without') 
plt.xlabel('Index')
plt.ylabel('value')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['san_od']) 
plt.title('san_od') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['Domestic general government health expenditure (% of GDP)']) 
plt.title('Domestic general government health expenditure (% of GDP)') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['wat_sm_number_without']) 
plt.title('wat_sm_number_without') 
plt.xlabel('Index')
plt.ylabel('value')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['Physicians (per 1,000 people)']) 
plt.title('Physicians (per 1,000 people)') 
plt.xlabel('Index')
plt.ylabel('value')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ']) 
plt.title('6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['6.3.2 - Proportion of river water bodies with good ambient water quality (%) - EN_H2O_RVAMBQ']) 
plt.title('6.3.2 - Proportion of river water bodies with good ambient water quality (%) - EN_H2O_RVAMBQ') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['6.3.2 - Proportion of groundwater bodies with good ambient water quality (%) - EN_H2O_GRAMBQ']) 
plt.title('6.3.2 - Proportion of groundwater bodies with good ambient water quality (%) - EN_H2O_GRAMBQ') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show()

plt.figure(figsize=(10, 10))
plt.scatter(merged_data.index,merged_data['6.3.2 - Proportion of open water bodies with good ambient water quality (%) - EN_H2O_OPAMBQ']) 
plt.title('6.3.2 - Proportion of open water bodies with good ambient water quality (%) - EN_H2O_OPAMBQ') 
plt.xlabel('Index')
plt.ylabel('percentage')  
plt.show() 

merged_data.to_csv('merged_data.csv', index=False)

#construct the data
merged_data["Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized"].describe()
import numpy as np

death_share_median = merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].median()

merged_data['death_share_risk'] = np.where(merged_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'] > death_share_median, 'high risk from unsafe water', 'less-vulnerable from unsafe water')

def income_class(gdp):
    if gdp <= 1025:
        return 'Low Income'
    elif 1025 < gdp <= 12475:
        return 'Middle Income'
    else:
        return 'High Income'

merged_data['income_class'] = merged_data['GDP per capita, PPP (constant 2017 international $)'].map(income_class)

merged_data.to_csv('merged_data.csv', index=False)

#reformat the numeric data to percentage
#diahrreal disease
merged_data['death_share_diarrheal_disease'] = (merged_data['death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges'] / merged_data['Population (historical estimates)']) * 100
#people who can't get improved water
merged_data['wat_imp_without_share'] = (merged_data['wat_imp_number_without'] / merged_data['Population (historical estimates)']) * 100
#people who can't get safe-drinking water
merged_data['wat_sm_without_share'] = (merged_data['wat_sm_number_without'] / merged_data['Population (historical estimates)']) * 100
#transform physician
merged_data['physician_count'] = merged_data['Population (historical estimates)'] * merged_data['Physicians (per 1,000 people)'] / 1000
merged_data['country_physicians_proportion'] = (merged_data['physician_count'] / merged_data['Population (historical estimates)']) * 100
merged_data = merged_data.drop(columns=['physician_count'])

merged_data = merged_data.drop(columns=['death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges'])
merged_data = merged_data.drop(columns=['wat_imp_number_without'])
merged_data = merged_data.drop(columns=['wat_sm_number_without'])
merged_data = merged_data.drop(columns=['Physicians (per 1,000 people)'])

merged_data.to_csv('merged_data.csv', index=False)
