# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 13:29:27 2023

@author: panti
"""

#data transformation
import pandas as pd

file = 'merged_data.csv'
merged_data = pd.read_csv(file)

#reduce data
merged_data = merged_data.drop(columns=['wat_sm_without_share'])

print(merged_data['Year'].value_counts())
merged_data = merged_data[merged_data['Year'] >= 2010]

merged_data.to_csv('merged_data.csv', index=False)

#project data
print(merged_data['death_share_risk'].value_counts())
'''
less-vulnerable from unsafe water    565
high risk from unsafe water          514
'''
from sklearn.utils import resample
merged_data_high = merged_data[merged_data['death_share_risk'] == 'less-vulnerable from unsafe water']
merged_data_low = merged_data[merged_data['death_share_risk'] == 'high risk from unsafe water']
merged_data_low_boost = resample(merged_data_low,replace=True, n_samples=len(merged_data_high))
merged_data_boost = pd.concat([merged_data_high, merged_data_low_boost])
print(merged_data_boost ['death_share_risk'].value_counts())

merged_data_boost.to_csv('merged_data_boost.csv', index=False)
