# -*- coding: utf-8 -*-
"""
Created on Sat Aug 19 17:10:03 2023

@author: tpan501
"""
#This data mining process's business objective is finding out the factors related to the high death rate of unsafe water and predict the future unsafe water death's trend.

import pandas as pd
file = 'access-drinking-water-stacked.csv'
access_drinking = pd.read_csv(file)
file2 = 'death-rates-unsafe-water.csv'
death_rates_unsafe_water = pd.read_csv(file2)
file3 = 'share-deaths-unsafe-water.csv'
death_share_unsafe_water = pd.read_csv(file3)
file4 =  'deaths-from-diarrheal-diseases-who.csv'
death_from_diarrheal_disease = pd.read_csv(file4)
file5 = 'historical-gov-spending-gdp.csv'
gov_spending = pd.read_csv(file5)
file6 = 'improved-water-sources-vs-gdp-per-capita.csv'
improved_water_sources_vs_gdp = pd.read_csv(file6)
file7 = 'number-without-improved-water.csv'
number_without_improved_water = pd.read_csv(file7)
file8 = 'number-without-safe-drinking-water.csv'
number_without_safe_drinking_water = pd.read_csv(file8)
file9= 'people-practicing-open-defecation-of-population.csv'
open_defecation = pd.read_csv(file9)
file10 = 'physicians-per-1000-people.csv'
physicians_number = pd.read_csv(file10)
file11 = 'public-healthcare-spending-share-gdp.csv'
healthcare_spending = pd.read_csv(file11)
file12 = 'public-health-expenditure-share-GDP-OWID.csv'
health_expenditure_share_GDP = pd.read_csv(file12)
file13 = 'healthcare-expenditure-vs-gdp.csv'
healthcare_expenditure_vs_GDP = pd.read_csv(file13)
file14 = 'water-bodies-good-water-quality.csv'
water_bodies_quality = pd.read_csv(file14)
#file12 = 'wastewater-safely-treated.csv'
#waste_water_treated = pd.read_csv(file12)
#file11 = 'share-of-health-facilities-with-essential-medicines.csv'
#health_facilities_medicines = pd.read_csv(file11)

import pandas as pd
import matplotlib.pyplot as plt

#pick out the countries for data visualization
#delete the regions
death_share_unsafe_water = death_share_unsafe_water.dropna(subset=['Code'])

#get the latest year
latest_year = death_share_unsafe_water['Year'].max()
latest_data = death_share_unsafe_water[death_share_unsafe_water['Year'] == latest_year]

top_5_countries = latest_data.nlargest(5, 'Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized')['Entity'].tolist()
bottom_5_countries = latest_data.nsmallest(5, 'Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized')['Entity'].tolist()
#calculate the median death share5
median_death_share = latest_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'].median()
# calculate countries' distance from the median
latest_data['distance_to_median'] = abs(latest_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'] - median_death_share)
median_5_countries = latest_data.nsmallest(5, 'distance_to_median')['Entity'].tolist()
selected_countries = top_5_countries + bottom_5_countries + median_5_countries

#death share visualization
selected_data = death_share_unsafe_water[death_share_unsafe_water['Entity'].isin(selected_countries)]

plt.figure(figsize=(20, 10))

for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Share of total deaths that are from all causes attributed to unsafe water source, in both sexes aged age-standardized'], country, fontsize=9)
    
plt.title('Percentage of Deaths due to Unsafe Water for Selected Countries over Years')
plt.xlabel('Year')
plt.ylabel('Death Percentage due to Unsafe Water')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#death rate
selected_data = death_rates_unsafe_water[death_rates_unsafe_water['Entity'].isin(selected_countries)]

plt.figure(figsize=(20, 10))

for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['Deaths that are from all causes attributed to unsafe water source per 100,000 people, in both sexes aged age-standardized'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Deaths that are from all causes attributed to unsafe water source per 100,000 people, in both sexes aged age-standardized'], country, fontsize=9)

plt.title('Rate of Deaths due to Unsafe Water for Selected Countries over Years')
plt.xlabel('Year')
plt.ylabel('Death rate due to Unsafe Water')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#countries' percentage of reaching safely managed water 
selected_data = access_drinking[access_drinking['Entity'].isin(selected_countries)]

plt.figure(figsize=(20, 10))

for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['wat_sm'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_sm'], country, fontsize=9)
    
plt.title('Percentage of people who can get safely managed water source')
plt.xlabel('Year')
plt.ylabel('percentage')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#countries' percentage of reaching basic water 
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['wat_bas_minus_sm'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_bas_minus_sm'], country, fontsize=9)
    
plt.title('Percentage of people who can get basic water source')
plt.xlabel('Year')
plt.ylabel('percentage')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()
#countries' percentage of reaching limited water 
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['wat_lim'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_lim'], country, fontsize=9)
    
plt.title('Percentage of people who can get limited water source')
plt.xlabel('Year')
plt.ylabel('percentage')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()
#countries' percentage of reaching unimproved water 
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['wat_unimp'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_unimp'], country, fontsize=9)
    
plt.title('Percentage of people who can get unimproved water source')
plt.xlabel('Year')
plt.ylabel('percentage')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()
#countries' percentage of reaching surface water 
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    plt.plot(country_data['Year'], country_data['wat_sur'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_sur'], country, fontsize=9)
    
plt.title('Percentage of people who can get surface water source')
plt.xlabel('Year')
plt.ylabel('percentage')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#countries' death number of diarrheal diseases 
selected_data = death_from_diarrheal_disease[death_from_diarrheal_disease['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['death_count - Cause: Diarrhoeal diseases - Sex: Both sexes - Age_group: ALLAges'], country, fontsize=9)
    
plt.title('Death number of diarrheal diseases')
plt.xlabel('Year')
plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#historical spending of government
selected_data = gov_spending[gov_spending['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['Government Expenditure (IMF based on Mauro et al. (2015))'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Government Expenditure (IMF based on Mauro et al. (2015))'], country, fontsize=9)
    
plt.title('Historical spending of government')
plt.xlabel('Year')
plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#improved-water-sources-vs-gdp-per-capita
#gdp per capita
selected_data = improved_water_sources_vs_gdp[improved_water_sources_vs_gdp['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'GDP per capita, PPP (constant 2017 international $)'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['GDP per capita, PPP (constant 2017 international $)'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['GDP per capita, PPP (constant 2017 international $)'], country, fontsize=9)
    
plt.title('GDP per capita of government')
plt.xlabel('Year')
#plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#population
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'Population (historical estimates)'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['Population (historical estimates)'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Population (historical estimates)'], country, fontsize=9)
    
plt.title('Population of government')
plt.xlabel('Year')
plt.xlim(2000, 2019)
plt.ylabel('population(*10 ^8)')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#number of people without accessing improved water
selected_data = number_without_improved_water[number_without_improved_water['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'wat_imp_number_without'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['wat_imp_number_without'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_imp_number_without'], country, fontsize=9)
    
plt.title('number of people without accessing improved water')
plt.xlabel('Year')
#plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#number of people without accessing safely drinking water
selected_data = number_without_safe_drinking_water[number_without_safe_drinking_water['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'wat_sm_number_without'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['wat_sm_number_without'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['wat_sm_number_without'], country, fontsize=9)
    
plt.title('number of people without accessing safe drinking water')
plt.xlabel('Year')
#plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#people-practicing-open-defecation-of-population
selected_data = open_defecation[open_defecation['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'san_od'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['san_od'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['san_od'], country, fontsize=9)
    
plt.title('percentage of people doing open defecation')
plt.xlabel('Year')
#plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#physicians-per-1000-people
selected_data = physicians_number[physicians_number['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'Physicians (per 1,000 people)'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['Physicians (per 1,000 people)'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Physicians (per 1,000 people)'], country, fontsize=9)
    
plt.title('number of physician per 1000 people')
plt.xlabel('Year')
plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#public-healthcare-spending-share-gdp
selected_data = healthcare_spending[healthcare_spending['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'Domestic general government health expenditure (% of GDP)'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['Domestic general government health expenditure (% of GDP)'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Domestic general government health expenditure (% of GDP)'], country, fontsize=9)
    
plt.title('percentage of healthcare spending as the proportion of GDP')
plt.xlabel('Year')
#plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()


#healthcare_expenditure_vs_GDP
selected_data = healthcare_expenditure_vs_GDP[healthcare_expenditure_vs_GDP['Entity'].isin(selected_countries)]
plt.figure(figsize=(20, 10))
for country in selected_countries:
    country_data = selected_data[selected_data['Entity'] == country]
    #filter the countries with NaN value
    country_data = country_data.dropna(subset=['Year', 'Current health expenditure per capita, PPP (current international $)'])
    #sort the year to avoid error visualization
    country_data = country_data.sort_values(by='Year')
    # check the current country existence
    if country_data.empty:  
        print(f"No data available for {country}. Skipping...")
        continue
    plt.plot(country_data['Year'], country_data['Current health expenditure per capita, PPP (current international $)'], label=country)
    last_point = country_data.iloc[-1]
    plt.text(last_point['Year'], last_point['Current health expenditure per capita, PPP (current international $)'], country, fontsize=9)
    
plt.title('Healthcare spending per capita')
plt.xlabel('Year')
plt.xlim(2000, 2019)
#plt.ylabel('death number')
plt.legend(loc='upper left')
plt.grid(True)
plt.tight_layout()
plt.show()

#water_bodies_quality
import seaborn as sns

selected_data = water_bodies_quality[(water_bodies_quality['Entity'].isin(selected_countries)) & (water_bodies_quality['Year'] == 2020)]

plt.figure(figsize=(15, 10))

sns.barplot(data=selected_data, x='Entity', y='6.3.2 - Proportion of bodies of water with good ambient water quality (%) - EN_H2O_WBAMBQ')

plt.title('water body quality of each country in 2020')
plt.xlabel('Country') 
plt.ylabel('water quality')
plt.show()


plt.figure(figsize=(15, 10))

sns.barplot(data=selected_data, x='Entity', y='6.3.2 - Proportion of river water bodies with good ambient water quality (%) - EN_H2O_RVAMBQ')

plt.title('water body quality (river) of each country in 2020')
plt.xlabel('Country') 
plt.ylabel('water quality')
plt.show()

selected_data = water_bodies_quality[(water_bodies_quality['Entity'].isin(selected_countries)) & (water_bodies_quality['Year'] == 2020)]

plt.figure(figsize=(15, 10))

sns.barplot(data=selected_data, x='Entity', y='6.3.2 - Proportion of groundwater bodies with good ambient water quality (%) - EN_H2O_GRAMBQ')

plt.title('water body quality(ground water) of each country in 2020')
plt.xlabel('Country') 
plt.ylabel('water quality')
plt.show()

selected_data = water_bodies_quality[(water_bodies_quality['Entity'].isin(selected_countries)) & (water_bodies_quality['Year'] == 2020)]

plt.figure(figsize=(15, 10))

sns.barplot(data=selected_data, x='Entity', y='6.3.2 - Proportion of open water bodies with good ambient water quality (%) - EN_H2O_OPAMBQ')

plt.title('water body quality(surface water) of each country in 2020')
plt.xlabel('Country') 
plt.ylabel('water quality')
plt.show()


#checking the missing value condition
access_drinking.isnull().sum()
death_rates_unsafe_water.isnull().sum()
death_share_unsafe_water.isnull().sum()
death_from_diarrheal_disease.isnull().sum()
gov_spending.isnull().sum()
improved_water_sources_vs_gdp.isnull().sum()
number_without_improved_water.isnull().sum()
number_without_safe_drinking_water.isnull().sum()
open_defecation.isnull().sum()
physicians_number.isnull().sum()
healthcare_spending.isnull().sum()
health_expenditure_share_GDP.isnull().sum()
healthcare_expenditure_vs_GDP.isnull().sum()
water_bodies_quality.isnull().sum()

access_drinking.describe()
death_rates_unsafe_water.describe()
death_share_unsafe_water.describe()
death_from_diarrheal_disease.describe()
gov_spending.describe()
improved_water_sources_vs_gdp.describe()
number_without_improved_water.describe()
number_without_safe_drinking_water.describe()
open_defecation.describe()
physicians_number.describe()
healthcare_spending.describe()
health_expenditure_share_GDP.describe()
healthcare_expenditure_vs_GDP.describe()
water_bodies_quality.describe()




access_drinking.isnull().sum()
death_rates_unsafe_water.isnull().sum()
death_share_unsafe_water.isnull().sum()
death_from_diarrheal_disease.isnull().sum()
open_defecation.isnull().sum()













